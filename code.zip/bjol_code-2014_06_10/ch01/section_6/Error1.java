public class Error1
{
   public static void main(String[] args)
   {
      System.ou.println("Hello, World!"); // A compile-time error. 
   }
}
