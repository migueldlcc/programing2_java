public class PrintTester
{
   public static void main(String[] args)
   {
      System.out.println(3 + 4); // Prints 7
      
      System.out.println("Hello"); // Prints "Hello World!" in two lines
      System.out.println("World!");

      System.out.print("00"); // Prints 00 but doesn't start a new line
      System.out.println(3 + 4); // Prints 7 and starts a new line

      System.out.println("Goodbye");
   }
}
